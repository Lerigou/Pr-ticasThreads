package Exercicios.Exercicio4;

public class SemaforoMain {
}
